//slick slider animation properties
$(document).ready(function(){
    $('.product__slider').slick({
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        slidesToShow: 4,
        infinite: true,
        prevArrow:'.arrow_prev',
        nextArrow:".arrow_next",

        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 2
                }
            }
        ]
    })
})

$(document).ready(function(){
    $('.featured__container').slick({
        autoplay: false,
        autoplaySpeed: 5000,
        arrows: true,
        slidesToShow: 1,
        infinite: true,
        prevArrow:'.arrow_prev-2',
        nextArrow:".arrow_next-2"
    })
})


//Scroll Trigger


if (window.innerWidth > 600) {
    gsap.registerPlugin(ScrollTrigger);
    
    function scrollAnimation() {
        gsap.from([".box__left",".box__right"], {
            transform: "translateY(230px)",
            scrollTrigger: {
                trigger: ".section-about",
                start: 'top bottom',
                stop: "bottom bottom",
                scrub: true,
                // markers: true
            }
        })
        
        gsap.from(".box__center", {
            transform: "translateY(-180px)",
            scrollTrigger: {
                trigger: ".section-about",
                start: 'top bottom',
                stop: 'bottom bottom',
                scrub: true
            }
        })
    
        gsap.from(".featured__bg", {
            transform: "translateX(-180px)",
            scrollTrigger: {
                trigger: ".section-featured",
                start: 'top bottom',
                scrub: true,
                // markers: true
            }
        })
    
        gsap.from(".featured__heading", {
            transform: "translateX(80px)",
            opacity: 0,
            scrollTrigger: {
                trigger: ".section-featured",
                start: 'top bottom',
                end: 'bottom bottom-=200',
                scrub: true,
                // markers: true
            }
        })
    
        gsap.from([".featured__paragraph",".featured__btn"], {
            transform: "translateX(50px)",
            opacity: 0,
            scrollTrigger: {
                trigger: ".section-featured",
                start: 'top bottom',
                end: 'bottom bottom-=200',
                scrub: true
            }
        })
    
        // gsap.from(".recipe__heading", {
        //     transform: "translateX(-100px)",
        //     scrollTrigger: {
        //         trigger: ".section-recipe",
        //         start: 'top bottom',
        //         stop: 'bottom top-=100',
        //         scrub: true
        //     }
        // })
    }
    
    window.addEventListener('load', function(){
        scrollAnimation();
    })
    /* the viewport is less than 768 pixels wide */
    $('.slider').slick();
  } 